package com.tomekl007.packt.booking;

import com.tomekl007.packt.model.Travel;

public interface BookingService {
    boolean book(Travel travel);
}
