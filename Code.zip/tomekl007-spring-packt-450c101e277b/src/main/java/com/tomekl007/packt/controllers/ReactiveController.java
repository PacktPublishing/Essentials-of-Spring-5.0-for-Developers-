package com.tomekl007.packt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import javax.ws.rs.core.MediaType;
import java.util.List;

@RestController()
public class ReactiveController {

    private final ReactiveTravelRepository travelRepository;

    @Autowired
    public ReactiveController(ReactiveTravelRepository travelRepository) {
        this.travelRepository = travelRepository;
    }

    @GetMapping("/reactive/travel/{userId}")
    public Mono<List<TravelDto>> getTravels(@PathVariable final String userId) {
        return travelRepository.getTravels(userId);
    }

    @PostMapping(value = "/reactive/travel", consumes = MediaType.APPLICATION_JSON)
    public Mono<TravelDto> addTravel(@RequestBody TravelDto travel) {
        return travelRepository.addTravel(travel);
    }

}
